{{- define "thin-agent.name" -}}
{{- default .Chart.Name .Values.component.name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "thin-agent.otelCollectorName" -}}
{{- printf "%s-%s" (include "thin-agent.fullname" .) .Values.otel.collectorName | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "thin-agent.fullname" -}}
{{- printf "%s-%s" .Release.Name (include "thin-agent.name" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "thin-agent.labels" -}}
app.kubernetes.io/name: {{ include "thin-agent.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{/*
ODA Component resource name: <release>-<component.name>. The longest derived
DNS-1035 name is the "<componentName>-orchagent" Service, so fail early when it
would exceed 63 characters.
*/}}
{{- define "thin-agent.componentName" -}}
{{- $name := printf "%s-%s" .Release.Name .Values.component.name -}}
{{- if gt (len (printf "%s-orchagent" $name)) 63 -}}
{{- fail (printf "release name + component.name is too long: %q-orchagent must be at most 63 characters" $name) -}}
{{- end -}}
{{- $name -}}
{{- end -}}

{{/*
Rejects duplicate (name, apiType) pairs in component.dependentAPIs.
*/}}
{{- define "thin-agent.validateDependentAPIs" -}}
{{- $seen := dict -}}
{{- range .Values.component.dependentAPIs -}}
{{- $key := printf "%s/%s" .name .apiType -}}
{{- if hasKey $seen $key -}}
{{- fail (printf "component.dependentAPIs declares %s (%s) more than once" .name .apiType) -}}
{{- end -}}
{{- $_ := set $seen $key true -}}
{{- end -}}
{{- end -}}

{{/*
Rejects component values that still hold a "replace-with" placeholder.
*/}}
{{- define "thin-agent.validatePlaceholders" -}}
{{- $c := .Values.component -}}
{{- $fields := list (list "component.name" $c.name) (list "component.id" $c.id) (list "component.description" $c.description) (list "component.functionalBlock" $c.functionalBlock) (list "component.maintainer.name" $c.maintainer.name) (list "component.owner.name" $c.owner.name) -}}
{{- range $index, $api := $c.dependentAPIs -}}
{{- $fields = append $fields (list (printf "component.dependentAPIs[%d].name" $index) $api.name) -}}
{{- end -}}
{{- range $fields -}}
{{- if hasPrefix "replace-with" (toString (index . 1)) -}}
{{- fail (printf "%s is still the placeholder %q. Set it to the value from your use-case guide." (index . 0) (index . 1)) -}}
{{- end -}}
{{- end -}}
{{- end -}}
